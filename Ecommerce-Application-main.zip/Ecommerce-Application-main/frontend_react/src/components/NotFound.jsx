import React from 'react';
import Loader from '../utils/Loader';

const NotFound = () => {
  return (
    <Loader />
  )
}

export default NotFound;